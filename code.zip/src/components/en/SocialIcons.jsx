import React from "react";
import { MDBContainer, MDBRow, MDBCol } from "mdb-react-ui-kit";

export default function App() {
  return (
    <>
      <MDBContainer>
        <MDBRow className="text-light text-center">
          <MDBCol size="8" className="ms-auto me-auto fw-bold text-white">
            <MDBRow className="text-center">
              <MDBCol className="py-3">
                <a href="https://t.me/zrxpad" className="text-light fs-md-4">
                  <img src={"img/social/telegram icon.png"} alt="" height={40} /> 
                  <span className="d-none d-md-inline">&nbsp; Telegram</span>
                </a>
              </MDBCol>
              <MDBCol className="py-3">
                <a
                  href="https://twitter.com/zrxpad"
                  className="text-light fs-md-4"
                >
                  <img src={"img/social/twitter.png"} alt="" height={40} /> 
                  <span className="d-none d-md-inline">&nbsp; Twitter</span>
                </a>
              </MDBCol>
              <MDBCol className="py-3">
                <a
                  href="https://github.com/zrxpad"
                  className="text-light fs-md-4"
                >
                  <img src={"img/social/github.png"} alt="" height={40} /> 
                  <span className="d-none d-md-inline">&nbsp; Github</span>
                </a>
              </MDBCol>
              <MDBCol className="py-3">
                <a
                  href="https://medium.com/@zrxpad"
                  className="text-light fs-md-4"
                >
                  <img src={"img/social/medium.png"} alt="" height={40} /> 
                  <span className="d-none d-md-inline">&nbsp; Medium</span>
                </a>
              </MDBCol>
            </MDBRow>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </>
  );
}

import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
} from "mdb-react-ui-kit";

export default function StayConnected() {
  return (
    <>
      <MDBContainer className="text-light pb-5 my-md-5 py-md-5">
        <MDBRow>
          <MDBCol>
            <h2 className="fw-bold text-white text-white">
              Stay <span className="text-gradient-3">Connected</span>
            </h2>
            <p>Join and follow our socials to stay connected and up to date.</p>
          </MDBCol>
        </MDBRow>
        <MDBRow>
          <MDBCol md="3" className="py-4">
            <MDBCard className="stay-connected-card-bg rounded-xxl h-100">
              <MDBCardBody className="px-5 py-4 rounded-xxl h-100">
                <MDBCardTitle className="fw-bold text-white">
                  <img src={"img/social/medium.png"} alt="" />
                  &nbsp; Medium
                </MDBCardTitle>
                <MDBCardText>
                  Check for detailed announcments, campaigns, upcoming IDOs, AMA
                  announcments and much more.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="3" className="py-4">
            <MDBCard className="stay-connected-card-bg rounded-xxl h-100">
              <MDBCardBody className="px-5 py-4 rounded-xxl h-100">
                <MDBCardTitle className="fw-bold text-white">
                  <img src={"img/social/twitter.png"} alt="" />
                  &nbsp; Twitter
                </MDBCardTitle>
                <MDBCardText>
                  The first place to go to for updates and short announcments
                  for ZXP.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="3" className="py-4">
            <MDBCard className="stay-connected-card-bg rounded-xxl h-100">
              <MDBCardBody className="px-5 py-4 rounded-xxl h-100">
                <MDBCardTitle className="fw-bold text-white">
                  <img src={"img/social/telegram icon.png"} alt="" />
                  &nbsp; Telegram
                </MDBCardTitle>
                <MDBCardText>
                  Join the chat and our largest community to discuss and talk
                  all about 0xpad.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="3" className="py-4">
            <MDBCard className="stay-connected-card-bg rounded-xxl h-100">
              <MDBCardBody className="px-5 py-4 rounded-xxl h-100">
                <MDBCardTitle className="fw-bold text-white">
                  <img src={"img/social/github.png"} alt="" />
                  &nbsp; Github
                </MDBCardTitle>
                <MDBCardText>
                  Check the 0xpad source code, both for the Token (ZXP) and the
                  launchpad, staking pools. Here you can also access CBC
                  records.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </>
  );
}

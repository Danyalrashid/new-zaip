import React from "react";
import { MDBContainer, MDBRow, MDBCol } from "mdb-react-ui-kit";

export default function OurVision() {
  return (
    <>
    <MDBContainer className="text-light pb-5 my-md-5 py-md-5">
        <MDBRow className="d-flex">
          <MDBCol md="6" className="py-4 align-self-center">
            <h2 className="fw-bold text-white">
              <span className="text-gradient-3">
什么是 </span>
我们的愿景
            </h2>
            <p className="lead">
            为我们的投资者带来最好的顶级项目和
              力争成为质量第一的launchpad
              空间，同时利用我们的网络提供最佳营销
              对初创公司的支持
            </p>
          </MDBCol>
          <MDBCol md="6" className="py-4 text-end">
            <img src={"img/our-vision.gif"} className="w-100" alt="" />
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </>
  );
}

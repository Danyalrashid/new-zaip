import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
} from "mdb-react-ui-kit";

export default function StayConnected() {
  return (
    <>
    <MDBContainer className="text-light pb-5 my-md-5 py-md-5">
        <MDBRow>
          <MDBCol>
            <h2 className="fw-bold text-white text-white">
              
停留 <span className="text-gradient-3">连接的</span>
            </h2>
            <p>加入并关注我们的社交活动以保持联系并了解最新信息.</p>
          </MDBCol>
        </MDBRow>
        <MDBRow>
          <MDBCol md="3" className="py-4">
            <MDBCard className="stay-connected-card-bg rounded-xxl h-100">
              <MDBCardBody className="px-5 py-4 rounded-xxl h-100">
                <MDBCardTitle className="fw-bold text-white">
                  <img src={"img/social/medium.png"} alt="" />
                  &nbsp; Medium
                </MDBCardTitle>
                <MDBCardText>
                  
查看详细的公告、活动、即将到来的 IDO、AMA
                  公告等等。
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="3" className="py-4">
            <MDBCard className="stay-connected-card-bg rounded-xxl h-100">
              <MDBCardBody className="px-5 py-4 rounded-xxl h-100">
                <MDBCardTitle className="fw-bold text-white">
                  <img src={"img/social/twitter.png"} alt="" />
                  &nbsp; Twitter
                </MDBCardTitle>
                <MDBCardText>
                获取更新和简短通知的第一个地方
                  对于 ZXP
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="3" className="py-4">
            <MDBCard className="stay-connected-card-bg rounded-xxl h-100">
              <MDBCardBody className="px-5 py-4 rounded-xxl h-100">
                <MDBCardTitle className="fw-bold text-white">
                  <img src={"img/social/telegram icon.png"} alt="" />
                  &nbsp; Telegram
                </MDBCardTitle>
                <MDBCardText>
                加入聊天和我们最大的社区进行讨论和交谈
                  关于 0xpad.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="3" className="py-4">
            <MDBCard className="stay-connected-card-bg rounded-xxl h-100">
              <MDBCardBody className="px-5 py-4 rounded-xxl h-100">
                <MDBCardTitle className="fw-bold text-white">
                  <img src={"img/social/github.png"} alt="" />
                  &nbsp; Github
                </MDBCardTitle>
                <MDBCardText>
                检查 0xpad 源代码，包括 代币
 (ZXP) 和
                  启动板，质押池。在这里您还可以访问 加拿大广播公司

                  记录.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </>
  );
}

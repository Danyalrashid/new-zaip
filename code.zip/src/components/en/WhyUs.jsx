import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
} from "mdb-react-ui-kit";

export default function WhyUs() {
  return (
    <div style={{ backgroundColor: "#000000" }}>
      <MDBContainer className="text-light pb-5 my-md-5 py-md-5 why-us-bg-img">
        <MDBRow>
          <MDBCol>
            <h2 className="fw-bold text-white mb-5">
              How we <span className="text-gradient-3">are different</span>
            </h2>
          </MDBCol>
        </MDBRow>
        <MDBRow className="position-relative">
          <MDBCol size={6} md="4" className="position-absolute mt-5 bottom-0 start-0 z-n1">
            <img
              src={"img/quality/leftEarth.png"}
              alt="left"
              className="w-100"
            />
          </MDBCol>
          <MDBCol size={6} md="4" className="position-absolute mt-5 bottom-0 end-0 z-n1">
            <img
              src={"img/quality/rightEarth.png"}
              alt="right"
              className="w-100"
            />
          </MDBCol>
          <MDBCol md="6" className="py-4">
            <MDBCard className="why-us-card-bg  rounded-xxl h-100">
              <MDBCardBody className=" p-3 rounded-xxl">
                <div className="top-icon">
                  <img src={"img/different/high-quality.png"} alt="" />
                </div>
                <MDBRow>
                  <MDBCol md="3"></MDBCol>
                  <MDBCol md="9" className="py-4">
                    <MDBCardTitle>
                      <h3 className="fw-bold text-white mt-5 mt-md-0">
                        Top Tier Project
                      </h3>
                    </MDBCardTitle>
                    <MDBCardText>
                      With the introduction of the CBC standard we do the due
                      dilligance so you dont have to. Now you can easily
                      participate in top tier projects and not have to think
                      before aping an investment.
                    </MDBCardText>
                  </MDBCol>
                </MDBRow>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="6" className="py-4">
            <MDBCard className="why-us-card-bg  rounded-xxl h-100">
              <MDBCardBody className=" p-3 rounded-xxl">
                <div className="top-icon">
                  <img src={"img/different/fair.png"} alt="" />
                </div>
                <MDBRow>
                  <MDBCol md="3"></MDBCol>
                  <MDBCol md="9" className="py-4">
                    <MDBCardTitle>
                      <h3 className="fw-bold text-white mt-5 mt-md-0">
                        Fair and Accessible
                      </h3>
                    </MDBCardTitle>
                    <MDBCardText>
                      With no minimum investment and a Subscription based
                      system, our launchpad makexs it fair for all bringing you
                      new projects that you usually would not have heard iof
                      until they are already mainstream! Now you dont have to be
                      a VC or in a private sale to get the best deals.
                    </MDBCardText>
                  </MDBCol>
                </MDBRow>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="6" className="py-4 mx-auto">
            <MDBCard className="why-us-card-bg  rounded-xxl h-100">
              <MDBCardBody className=" p-3 rounded-xxl">
                <div className="top-icon">
                  <img src={"img/different/hybrid.png"} alt="" />
                </div>
                <MDBRow>
                  <MDBCol md="3"></MDBCol>
                  <MDBCol md="9" className="py-4">
                    <MDBCardTitle>
                      <h3 className="fw-bold text-white mt-5 mt-md-0">
                        Hybrid Fundraiser
                      </h3>
                    </MDBCardTitle>
                    <MDBCardText>
                      Many projects fail due to poor marketing and budget
                      allocations. With our hybrid fundraiser we leverage our
                      connections to get premium prices and offer a range of
                      campaigns at absurd discounts to make sure every project
                      that launches with us does so with the right marketing
                      boost.
                    </MDBCardText>
                  </MDBCol>
                </MDBRow>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </div>
  );
}

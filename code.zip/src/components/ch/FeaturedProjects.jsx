import React, { Component } from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
  MDBCardImage,
  MDBBtn,
} from "mdb-react-ui-kit";
import Slider from "react-slick";

var settings = {
  className: "center",
  centerMode: false,
  centerPadding: "60px",
  dots: false,
  infinite: true,
  speed: 500,
  slidesToShow: 4,
  slidesToScroll: 1,
  initialSlide: 0,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true,
      },
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        initialSlide: 2,
      },
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
      },
    },
  ],
};

export default function FeaturedProjects() {
  return (
    <div className="text-white pb-5 my-md-5 py-md-5">
      <MDBContainer className="text-light my-5">
        <MDBRow>
          <MDBCol>
            <h2 className="fw-bold text-white">精选

              <span className="text-gradient-3"> 项目
</span>
            </h2>
            <p>
            请注意，此部分用于赞助项目，不
              保证我们的参与或投入。这纯粹是一个评级和
              评估，不应被视为财务建议。对于等级
              1 个项目请使用我们的 
发射台
            </p>
          </MDBCol>
        </MDBRow>
        <MDBRow className="overflow-md-hidden">
          <MDBCol className="mx-auto" size={10} md="12">
          <Slider {...settings} className="text-center">
            <div>
              <MDBCard className="featured-project-card m-3 rounded-xl position-relative border-0">
                <MDBCardImage
                  src="https://config-cms.impossible.finance/images/app-banner_pine_lp-ido_574x396px.png"
                  className="rounded-t-xl"
                  position="top"
                  style={{ height: "200px" }}
                  alt="..."
                />
                <div className="position-absolute top-0 start-0 p-2">
                  <span className="badge rounded-pill text-bg-pink">
                    #非同质化代币
                  </span>
                </div>
                
                <MDBCardBody className="rounded-xl">
                  <MDBCardTitle>
                    <h4 className="fw-bold text-white">御纸B美元
</h4>
                  </MDBCardTitle>
                  <MDBCardText>
                    在卡片上构建的一些快速示例文本。
                  </MDBCardText>
                  <button class="btn-custom">加拿大广播公司纪录</button>
                </MDBCardBody>
              </MDBCard>
            </div>
            <div>
              <MDBCard className="featured-project-card m-3 rounded-xl position-relative border-0">
                <MDBCardImage
                  src="https://config-cms.impossible.finance/images/app-banner_pine_lp-ido_574x396px.png"
                  className="rounded-t-xl"
                  position="top"
                  style={{ height: "200px" }}
                  alt="..."
                />
                <div className="position-absolute top-0 start-0 p-2">
                  <span className="badge rounded-pill text-bg-pink">
                    #非同质化代币
                  </span>
                </div>
                
                <MDBCardBody className="rounded-xl">
                  <MDBCardTitle>
                    <h4 className="fw-bold text-white">御纸B美元</h4>
                  </MDBCardTitle>
                  <MDBCardText>
                    在卡片上构建的一些快速示例文本。
                  </MDBCardText>
                  <button class="btn-custom">加拿大广播公司纪录</button>
                </MDBCardBody>
              </MDBCard>
            </div>
            <div>
              <MDBCard className="featured-project-card m-3 rounded-xl position-relative border-0">
                <MDBCardImage
                  src="https://config-cms.impossible.finance/images/app-banner_pine_lp-ido_574x396px.png"
                  className="rounded-t-xl"
                  position="top"
                  style={{ height: "200px" }}
                  alt="..."
                />
                <div className="position-absolute top-0 start-0 p-2">
                  <span className="badge rounded-pill text-bg-pink">
                    #非同质化代币
                  </span>
                </div>
                
                <MDBCardBody className="rounded-xl">
                  <MDBCardTitle>
                    <h4 className="fw-bold text-white">Pine Protocol</h4>
                  </MDBCardTitle>
                  <MDBCardText>
                    在卡片上构建的一些快速示例文本。
                  </MDBCardText>
                  <button class="btn-custom">加拿大广播公司纪录</button>
                </MDBCardBody>
              </MDBCard>
            </div>
            <div>
              <MDBCard className="featured-project-card m-3 rounded-xl position-relative border-0">
                <MDBCardImage
                  src="https://config-cms.impossible.finance/images/app-banner_pine_lp-ido_574x396px.png"
                  className="rounded-t-xl"
                  position="top"
                  style={{ height: "200px" }}
                  alt="..."
                />
                <div className="position-absolute top-0 start-0 p-2">
                  <span className="badge rounded-pill text-bg-pink">
                    #非同质化代币
                  </span>
                </div>
                
                <MDBCardBody className="rounded-xl">
                  <MDBCardTitle>
                    <h4 className="fw-bold text-white">Ruby</h4>
                  </MDBCardTitle>
                  <MDBCardText>
                    在卡片上构建的一些快速示例文本。
                  </MDBCardText>
                  <button class="btn-custom">加拿大广播公司纪录</button>
                </MDBCardBody>
              </MDBCard>
            </div>
            <div>
              <MDBCard className="featured-project-card m-3 rounded-xl position-relative border-0">
                <MDBCardImage
                  src="https://config-cms.impossible.finance/images/app-banner_pine_lp-ido_574x396px.png"
                  className="rounded-t-xl"
                  position="top"
                  style={{ height: "200px" }}
                  alt="..."
                />
                <div className="position-absolute top-0 start-0 p-2">
                  <span className="badge rounded-pill text-bg-pink">
                    #非同质化代币
                  </span>
                </div>
                
                <MDBCardBody className="rounded-xl">
                  <MDBCardTitle>
                    <h4 className="fw-bold text-white">虚拟的</h4>
                  </MDBCardTitle>
                  <MDBCardText>
                    在卡片上构建的一些快速示例文本。
                  </MDBCardText>
                  <button class="btn-custom">加拿大广播公司纪录</button>
                </MDBCardBody>
              </MDBCard>
            </div>
          </Slider>
          </MDBCol>
        </MDBRow>
        <MDBRow className="text-center mt-5">
          <a href="https://github.com/zrxpad/CBC-records" className="btn-link">查看更多</a>
        </MDBRow>
      </MDBContainer>
    </div>
  );
}

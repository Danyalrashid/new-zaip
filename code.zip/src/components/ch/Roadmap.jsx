import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
} from "mdb-react-ui-kit";

export default function Roadmap() {
  return (
    <>
    <MDBContainer className="text-light pb-5 my-md-5 py-md-5 roadmap-desktop-bg">
        <MDBRow>
          <MDBCol className="mb-5">
            <h2 className="fw-bold text-white">
              <span className="text-gradient-3">时间线</span>
            </h2>
            <p>跨越 2023 年的重要事件时间表.</p>
          </MDBCol>
        </MDBRow>
        <MDBRow>
          <MDBCol size={12}>
            <img src={"/img/timeline.jpg"} alt="" style={{ width: "100%" }} />
          </MDBCol>
          <MDBCol md="4" className="py-4">
            <MDBCard className="roadmap-card-bg rounded-xxl">
              <MDBCardBody className=" p-5 rounded-xxl">
                <MDBCardTitle>
                  <h3 className="fw-bold text-white ">
                    <img src={"img/icon.png"} alt="" height={25} />{" "}
                    &nbsp;
                    <span className="text-white">Q1 2023</span>
                  </h3>
                </MDBCardTitle>
                <MDBCardText>
                  <ul>
                    <li>IDO Pad dApp (BSC, ETH)</li>
                    <li>加拿大广播公司 补偿背景调查</li>
                    <li>T2 CEX  清单</li>
                  </ul>
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="4" className="py-4">
            <MDBCard className="roadmap-card-bg rounded-xxl">
              <MDBCardBody className=" p-5 rounded-xxl">
                <MDBCardTitle>
                  <h3 className="fw-bold text-white ">
                    <img src={"img/icon.png"} alt="" height={25} />{" "}
                    &nbsp;
                    <span className="text-white">Q2 2023</span>
                  </h3>
                </MDBCardTitle>
                <MDBCardText>
                  <ul>
                    <li>加速器计划 </li>
                    <li>T1 CEX 房源</li>
                    <li>空投用户获取</li>
                  </ul>
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="4" className="py-4">
            <MDBCard className="roadmap-card-bg rounded-xxl">
              <MDBCardBody className=" p-5 rounded-xxl">
                <MDBCardTitle>
                  <h3 className="fw-bold text-white ">
                    <img src={"img/icon.png"} alt="" height={25} />{" "}
                    &nbsp;
                    <span className="text-white">Q3 2023</span>
                  </h3>
                </MDBCardTitle>
                <MDBCardText>
                  <ul>
                    <li>
多链兼容性</li>
                    <li>合作伙伴和 VC 入职</li>
                    <li>
德根 发射台
 dApp</li>
                  </ul>
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </>
  );
}

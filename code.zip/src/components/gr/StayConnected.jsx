import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
} from "mdb-react-ui-kit";

export default function StayConnected() {
  return (
    <>
      <MDBContainer className="text-light pb-5 my-md-5 py-md-5">
        <MDBRow>
          <MDBCol>
            <h2 className="fw-bold text-white text-white">
              Bleibe{" "}
              <span className="text-gradient-3">In Verbindung gebracht</span>
            </h2>
            <p>
              Treten Sie unseren sozialen Netzwerken bei und folgen Sie ihnen,
              um in Verbindung zu bleiben und auf dem Laufenden zu bleiben.
            </p>
          </MDBCol>
        </MDBRow>
        <MDBRow>
          <MDBCol md="3" className="py-4">
            <MDBCard className="stay-connected-card-bg rounded-xxl h-100">
              <MDBCardBody className="px-5 py-4 rounded-xxl h-100">
                <MDBCardTitle className="fw-bold text-white">
                  <img src={"img/social/medium.png"} alt="" />
                  &nbsp; Medium
                </MDBCardTitle>
                <MDBCardText>
                  Suchen Sie nach detaillierten Ankündigungen, Kampagnen,
                  bevorstehenden IDOs, AMA Ankündigungen und vieles mehr.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="3" className="py-4">
            <MDBCard className="stay-connected-card-bg rounded-xxl h-100">
              <MDBCardBody className="px-5 py-4 rounded-xxl h-100">
                <MDBCardTitle className="fw-bold text-white">
                  <img src={"img/social/twitter.png"} alt="" />
                  &nbsp; Twitter
                </MDBCardTitle>
                <MDBCardText>
                  Die erste Anlaufstelle für Updates und Kurzmitteilungen für
                  ZXP.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="3" className="py-4">
            <MDBCard className="stay-connected-card-bg rounded-xxl h-100">
              <MDBCardBody className="px-5 py-4 rounded-xxl h-100">
                <MDBCardTitle className="fw-bold text-white">
                  <img src={"img/social/telegram icon.png"} alt="" />
                  &nbsp; Telegram
                </MDBCardTitle>
                <MDBCardText>
                  Treten Sie dem Chat und unserer größten Community bei, um zu
                  diskutieren und zu sprechen alles über 0xpad.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="3" className="py-4">
            <MDBCard className="stay-connected-card-bg rounded-xxl h-100">
              <MDBCardBody className="px-5 py-4 rounded-xxl h-100">
                <MDBCardTitle className="fw-bold text-white">
                  <img src={"img/social/github.png"} alt="" />
                  &nbsp; Github
                </MDBCardTitle>
                <MDBCardText>
                  Überprüfen Sie den 0xpad-Quellcode, sowohl für den Token (ZXP)
                  als auch für den Launchpad, Staking-Pools. Hier können Sie
                  auch auf CBC zugreifen Aufzeichnungen.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </>
  );
}

import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
} from "mdb-react-ui-kit";

export default function OurValues() {
  return (
    <>
    <MDBContainer className="text-light pb-5 my-md-5 py-md-5">
        <MDBRow>
          <MDBCol>
            <h2 className="fw-bold text-white">
              <span className="text-gradient-3">Was ist </span>Oxpad
            </h2>
            <p>
            Wir sind ein hybrides Launchpad der Spitzenklasse, das eine Reihe von Produkten anbietet, darunter eine Spendenaktion, Swaps, Liquiditätsabsteckungen und einen Marketingbeschleuniger.
            </p>
          </MDBCol>
        </MDBRow>
        <MDBRow>
          <MDBCol md="4" className="py-4 mt-5">
            <MDBCard className="impossible-card-bg  rounded-xxl h-100">
              <div className="top-icon">
                <img src={"img/value/launchpad.png"} alt="" />
              </div>
              <MDBCardBody className="p-5 rounded-xxl">
                <MDBCardTitle>
                  <h3 className="fw-bold text-white">Startrampe</h3>
                </MDBCardTitle>
                <MDBCardText>
                Wir bieten Ihnen nur die hochwertigsten Krypto-Projekte der Spitzenklasse und bekannte/überprüfte Teams. Setzen Sie ZXP ein, um eine Allokation zum Investieren zu erhalten.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="4" className="py-4 mt-5">
            <MDBCard className="impossible-card-bg  rounded-xxl h-100">
              <div className="top-icon">
                <img src={"img/value/cbc.png"} alt="" />
              </div>
              <MDBCardBody className="p-5 rounded-xxl">
                <MDBCardTitle>
                  <h3 className="fw-bold text-white">CBC</h3>
                </MDBCardTitle>
                <MDBCardText>
                Unsere umfassende Zuverlässigkeitsüberprüfung (CBC) wird ein neues einführen
                  Standard für ein KYC, wo das ganze Team und Projekt ist
                  ähnlich einem Audit bewertet und mit einer Punktzahl von 100 bewertet
                  Prüfbericht.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="4" className="py-4 mt-5">
            <MDBCard className="impossible-card-bg  rounded-xxl h-100">
              <div className="top-icon">
                <img src={"img/value/accel.png"} alt="" />
              </div>
              <MDBCardBody className="p-5 rounded-xxl">
                <MDBCardTitle>
                  <h3 className="fw-bold text-white">Beschleuniger</h3>
                </MDBCardTitle>
                <MDBCardText>
                Unser Accelerator ermöglicht garantierte Renditen für die Spitze
                  Stapler-Zuteilungen, wo Projekte mit hoher CBC-Punktzahl sein werden
                  ausgewählt, um eine vollständige Kampagne zu erhalten, die von VCs finanziert wird, um ihnen zu helfen
                  Vorverkauf.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </>
  );
}

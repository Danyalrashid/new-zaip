import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBDropdown,
  MDBDropdownItem,
  MDBDropdownMenu,
  MDBDropdownToggle,
} from "mdb-react-ui-kit";
import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <>
      <div className="container-fluid gradient-line"></div>
      <div className="bg-dark-blue text-light">
        <MDBContainer className=" py-5">
          <MDBRow>
            <MDBCol md="4" className="py-4">
              <div>
                <img src={"img/logo.png"} height={50} alt="" />
              </div>
              <div className="mt-3 d-none d-md-block">
                <a href="https://t.me/zrxpad">
                  <img
                    height={30}
                    src={"img/social/telegram icon.png"}
                    alt=""
                  />{" "}
                  &nbsp;
                </a>
                <a href="https://twitter.com/zrxpad">
                  <img height={30} src={"img/social/twitter.png"} alt="" />{" "}
                  &nbsp;
                </a>
                <a href="https://github.com/zrxpad">
                  <img height={30} src={"img/social/github.png"} alt="" />{" "}
                  &nbsp;
                </a>
                <a href="https://medium.com/@zrxpad">
                  <img height={30} src={"img/social/medium.png"} alt="" />
                </a>
              </div>
            </MDBCol>
            <MDBCol size={6} md="2" className="py-4">
              <p className="text-decoration-underline text-capitalize lead">
                投资
              </p>
              <p><a href="https://dapp.0xpad.app/invest" className="text-white">发射台</a></p>
              <p className="text-decoration-underline text-capitalize lead">
                贸易
              </p>
              <p><a href="https://dapp.0xpad.app/trade" className="text-white">交换</a></p>
              <p><a href="https://dapp.0xpad.app/trade" className="text-white">流动性</a></p>
            </MDBCol>
            <MDBCol size={6} md="2" className="py-4">
              <p className="text-decoration-underline text-capitalize lead">
                买 ZXP
              </p>
              <p><a href="https://dapp.0xpad.app/trade" className="text-white">0x 交换</a></p>
              <p>煎饼交换 </p>
            </MDBCol>
            <MDBCol size={6} md="2" className="py-4">
              <p className="text-decoration-underline text-capitalize lead">公司</p>
              <p><a href="https://medium.com/@zrxpad" className="text-white">中等的</a></p>
              <p><a href="https://0xpads-organization.gitbook.io/company-and-jobs-1/" className="text-white">职位公告板</a></p>
              <p><a href="https://0xpads-organization.gitbook.io/company-and-jobs-1/" className="text-white">分析</a> </p>
              <p className="text-decoration-underline text-capitalize lead">
                支持
              </p>
              <p><a href="https://0xpads-organization.gitbook.io/support/" className="text-white">常问问题</a></p>
            </MDBCol>
            <MDBCol size={6} md="2" className="py-4">
              <p className="text-decoration-underline text-capitalize lead">
                开发商
              </p>
              <p><a href="https://github.com/zrxpad" className="text-white">Github</a></p>
              <p><a href="https://0xpads-organization.gitbook.io/untitled-1/" className="text-white">GitBook</a></p>
              <MDBDropdown>
                <MDBDropdownToggle tag="a" className="btn btn-light btn-sm">
                  Language
                </MDBDropdownToggle>
                <MDBDropdownMenu>
                  <MDBDropdownItem className="px-3 py-1">
                    <Link className="nav-link text-dark" to="/gr">
                      German &nbsp;
                      <img src={"/img/flag/germany.png"} height={25} alt="" />
                    </Link>
                  </MDBDropdownItem>
                  <MDBDropdownItem className="px-3 py-1">
                    <Link className="nav-link text-dark" to="/">
                      English &nbsp;
                      <img src={"/img/flag/uk.png"} height={25} alt="" />
                    </Link>
                  </MDBDropdownItem>
                </MDBDropdownMenu>
              </MDBDropdown>
            </MDBCol>
          </MDBRow>
        </MDBContainer>
        <MDBContainer className="small pb-5 mb-5 py-md-3 text-center">
          0xpad &copy; 2023
        </MDBContainer>
      </div>
    </>
  );
}

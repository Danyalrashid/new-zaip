import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
} from "mdb-react-ui-kit";

export default function OurValues() {
  return (
    <>
      <MDBContainer className="text-light pb-5 my-md-5 py-md-5">
        <MDBRow>
          <MDBCol>
            <h2 className="fw-bold text-white">
              <span className="text-gradient-3">What is </span>Oxpad
            </h2>
            <p>
              We are a hybrid top tier launchpad offering a suite of products
              including a fundraiser, swap, liquidity staking and a marketing
              accelerator.
            </p>
          </MDBCol>
        </MDBRow>
        <MDBRow>
          <MDBCol md="4" className="py-4 mt-5">
            <MDBCard className="impossible-card-bg  rounded-xxl h-100">
              <div className="top-icon">
                <img src={"img/value/launchpad.png"} alt="" />
              </div>
              <MDBCardBody className="p-5 rounded-xxl">
                <MDBCardTitle>
                  <h3 className="fw-bold text-white">Launchpad</h3>
                </MDBCardTitle>
                <MDBCardText>
                  Bringing you only the highest of quality, top tier crypto
                  projects and known/vetted teams. Stake ZXP to earn allocation
                  to invest.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="4" className="py-4 mt-5">
            <MDBCard className="impossible-card-bg  rounded-xxl h-100">
              <div className="top-icon">
                <img src={"img/value/cbc.png"} alt="" />
              </div>
              <MDBCardBody className="p-5 rounded-xxl">
                <MDBCardTitle>
                  <h3 className="fw-bold text-white">CBC</h3>
                </MDBCardTitle>
                <MDBCardText>
                  Our comprehensive background check (CBC) will introduce a new
                  standard for a KYC where the whole team and project is
                  evaluated and rated with a score out of 100 much like a Audit
                  report.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="4" className="py-4 mt-5">
            <MDBCard className="impossible-card-bg  rounded-xxl h-100">
              <div className="top-icon">
                <img src={"img/value/accel.png"} alt="" />
              </div>
              <MDBCardBody className="p-5 rounded-xxl">
                <MDBCardTitle>
                  <h3 className="fw-bold text-white">Accelerator</h3>
                </MDBCardTitle>
                <MDBCardText>
                  Our Accelerator will allow for guaranteed returns fot the top
                  stackers allocations, where high CBC scoring projects will be
                  chosen to receive a full campaign funded by VCs to aid their
                  pre sale.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </>
  );
}

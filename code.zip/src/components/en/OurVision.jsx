import React from "react";
import { MDBContainer, MDBRow, MDBCol } from "mdb-react-ui-kit";

export default function OurVision() {
  return (
    <>
      <MDBContainer className="text-light pb-5 my-md-5 py-md-5">
        <MDBRow className="d-flex">
          <MDBCol md="6" className="py-4 align-self-center">
            <h2 className="fw-bold text-white">
              <span className="text-gradient-3">What is </span>
              our Vision
            </h2>
            <p className="lead">
              To bring our investors the best of the best top tier projects and
              strive to be the number 1 launchpad in terms of quality in the
              space while leveraging our network to provide the best marketing
              support for startups.
            </p>
          </MDBCol>
          <MDBCol md="6" className="py-4 text-end">
            <img src={"img/our-vision.gif"} className="w-100" alt="" />
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </>
  );
}

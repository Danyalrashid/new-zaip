import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
} from "mdb-react-ui-kit";

export default function OurValues() {
  return (
    <>
    <MDBContainer className="text-light pb-5 my-md-5 py-md-5">
        <MDBRow>
          <MDBCol>
            <h2 className="fw-bold text-white">
              <span className="text-gradient-3">什么是
 </span>牛皮纸

            </h2>
            <p>
              
我们是一个混合顶级发射台，提供一套产品
              包括筹款活动、互换、流动性质押和营销
              加速器。
            </p>
          </MDBCol>
        </MDBRow>
        <MDBRow>
          <MDBCol md="4" className="py-4 mt-5">
            <MDBCard className="impossible-card-bg  rounded-xxl h-100">
              <div className="top-icon">
                <img src={"img/value/launchpad.png"} alt="" />
              </div>
              <MDBCardBody className="p-5 rounded-xxl">
                <MDBCardTitle>
                  <h3 className="fw-bold text-white">发射台
</h3>
                </MDBCardTitle>
                <MDBCardText>
                 
只为您带来最高质量的顶级加密货币
                  项目和已知/经过审查的团队。质押 ZXP 以赚取分配
                  投资。
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="4" className="py-4 mt-5">
            <MDBCard className="impossible-card-bg  rounded-xxl h-100">
              <div className="top-icon">
                <img src={"img/value/cbc.png"} alt="" />
              </div>
              <MDBCardBody className="p-5 rounded-xxl">
                <MDBCardTitle>
                  <h3 className="fw-bold text-white">加拿大广播公司
</h3>
                </MDBCardTitle>
                <MDBCardText>
                  
我们的综合背景调查 (加拿大广播公司
) 将引入一个新的
                  
了解你的客户 的标准，整个团队和项目都是
                  以 100 分满分的方式进行评估和评分，就像审计一样
                  报告。
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="4" className="py-4 mt-5">
            <MDBCard className="impossible-card-bg  rounded-xxl h-100">
              <div className="top-icon">
                <img src={"img/value/accel.png"} alt="" />
              </div>
              <MDBCardBody className="p-5 rounded-xxl">
                <MDBCardTitle>
                  <h3 className="fw-bold text-white">
加速器</h3>
                </MDBCardTitle>
                <MDBCardText>
                我们的加速器将保证最高层的回报
                  堆垛机分配，高 
加拿大广播公司 评分项目将在其中
                  选择接受由风投资助的完整活动，以帮助他们
                  预售。
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </>
  );
}

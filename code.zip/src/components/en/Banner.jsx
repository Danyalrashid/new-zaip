import React from "react";
import { MDBContainer, MDBRow, MDBCol } from "mdb-react-ui-kit";

export default function Banner() {
  return (
    <>
      <MDBContainer className="mt-2 mt-md-5">
        <MDBRow className="text-light">
          <MDBCol lg="1" className="py-3"></MDBCol>
          <MDBCol lg="6" className="py-3">
            <div className="p-4">
              <h1 className="display-4 fw-bold text-white">
                A Top Tier <br />
                Hybrid Accelerator
              </h1>
              <p className="mt-3">
                0xpad is a hybrid fundraiser fusing marketing along an
                innovative borrow mechanism to raise funds for startups,
                guarantee returns for investors, in addition to introducing the
                CBC standard.
              </p>

              <div className="py-4">
                <a href="https://medium.com/@zrxpad/a-suite-of-defi-products-in-a-zrx-wrapper-b3a0f222997d" className="btn-2 my-1">Learn more</a>
                <a href="https://dapp.0xpad.app/invest" className="btn-3 my-1">Launch App</a>
              </div>
            </div>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </>
  );
}

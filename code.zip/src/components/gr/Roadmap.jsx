import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
} from "mdb-react-ui-kit";

export default function Roadmap() {
  return (
    <>
    <MDBContainer className="text-light pb-5 my-md-5 py-md-5 roadmap-desktop-bg">
        <MDBRow>
          <MDBCol className="mb-5">
            <h2 className="fw-bold text-white">
              <span className="text-gradient-3">Zeitleiste</span>
            </h2>
            <p>Zeitleiste der wichtigsten Ereignisse im Jahr 2023.</p>
          </MDBCol>
        </MDBRow>
        <MDBRow>
          <MDBCol size={12}>
            <img src={"/img/timeline.jpg"} alt="" style={{ width: "100%" }} />
          </MDBCol>
          <MDBCol md="4" className="py-4">
            <MDBCard className="roadmap-card-bg rounded-xxl">
              <MDBCardBody className=" p-5 rounded-xxl">
                <MDBCardTitle>
                  <h3 className="fw-bold text-white ">
                    <img src={"img/icon.png"} alt="" height={25} />{" "}
                    &nbsp;
                    <span className="text-white">Q1 2023</span>
                  </h3>
                </MDBCardTitle>
                <MDBCardText>
                  <ul>
                    <li>IDO Pad dApp (BSC, ETH)</li>
                    <li>CBC Comp-Hintergrundprüfung</li>
                    <li>T2 CEX-Auflistungen</li>
                  </ul>
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="4" className="py-4">
            <MDBCard className="roadmap-card-bg rounded-xxl">
              <MDBCardBody className=" p-5 rounded-xxl">
                <MDBCardTitle>
                  <h3 className="fw-bold text-white ">
                    <img src={"img/icon.png"} alt="" height={25} />{" "}
                    &nbsp;
                    <span className="text-white">Q2 2023</span>
                  </h3>
                </MDBCardTitle>
                <MDBCardText>
                  <ul>
                    <li>Accelerator-Programm
 </li>
                    <li>T1 CEX-Auflistungen
</li>
                    <li>Airdrop-Benutzergewinnung
</li>
                  </ul>
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="4" className="py-4">
            <MDBCard className="roadmap-card-bg rounded-xxl">
              <MDBCardBody className=" p-5 rounded-xxl">
                <MDBCardTitle>
                  <h3 className="fw-bold text-white ">
                    <img src={"img/icon.png"} alt="" height={25} />{" "}
                    &nbsp;
                    <span className="text-white">Q3 2023</span>
                  </h3>
                </MDBCardTitle>
                <MDBCardText>
                  <ul>
                    <li>Kompatibilität mit mehreren Ketten
</li>
                    <li>Partner und VC-Onboarding
</li>
                    <li>Degen Launchpad dApp
</li>
                  </ul>
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </>
  );
}

import React, { useState } from "react";
import {
  MDBContainer,
  MDBNavbar,
  MDBNavbarBrand,
  MDBNavbarNav,
  MDBNavbarItem,
  MDBNavbarLink,
  MDBDropdown,
  MDBDropdownToggle,
  MDBDropdownMenu,
  MDBDropdownItem,
  MDBCollapse,
  MDBRow,
  MDBCol,
  MDBBtn,
  MDBModal,
  MDBModalDialog,
  MDBModalContent,
  MDBModalHeader,
  MDBModalTitle,
  MDBModalBody,
} from "mdb-react-ui-kit";
import { Link } from "react-router-dom";

export default function MainNavbar() {
  const [basicModal, setBasicModal] = useState(false);
  const toggleShow = () => setBasicModal(!basicModal);

  return (
    <>
      <div className="container d-block d-md-none">
        <div className="row">
          <div className="col">
            <img src={"img/logo.png"} height={40} alt="" />
          </div>
        </div>
      </div>

      <MDBNavbar expand="md" dark className="py-4 d-none d-md-block">
        <MDBContainer>
          <MDBNavbarBrand>
            <img src={"img/logo.png"} height={40} alt="" />
          </MDBNavbarBrand>

          <MDBCollapse navbar>
            <MDBNavbarNav className="mr-auto mb-2 mb-lg-0 fw-bold">
              <MDBNavbarItem className="mx-4">
                <MDBNavbarLink
                  href="https://dapp.0xpad.app/invest"
                  className="text-white"
                >
                  投资
                </MDBNavbarLink>
              </MDBNavbarItem>

              <MDBNavbarItem className="mx-4">
                <MDBNavbarLink
                  href="https://dapp.0xpad.app/trade"
                  className="text-white"
                >
                  交换
                </MDBNavbarLink>
              </MDBNavbarItem>

              <MDBNavbarItem className="mx-4">
                <MDBNavbarLink
                  href="https://medium.com/@zrxpad/cbc-comprehensive-background-check-c4fd3a6d6518"
                  className="text-white"
                >
                  加拿大广播公司
                </MDBNavbarLink>
              </MDBNavbarItem>

              <MDBNavbarItem className="mx-4">
                <MDBNavbarLink
                  href="https://dapp.0xpad.app/trade"
                  className="text-white"
                >
                  流动性
                </MDBNavbarLink>
              </MDBNavbarItem>

              <MDBNavbarItem className="mx-4">
                <MDBNavbarLink
                  href="https://0xpads-organization.gitbook.io/support/"
                  className="text-white"
                >
                  常问问题
                </MDBNavbarLink>
              </MDBNavbarItem>

              <MDBNavbarItem className="mx-4">
                <MDBNavbarLink href={"whitepaper.pdf"} className="text-white">
                  白皮书
                </MDBNavbarLink>
              </MDBNavbarItem>

              <MDBNavbarItem>
                <MDBDropdown>
                  <MDBDropdownToggle
                    tag="a"
                    className="nav-link text-white"
                    role="button"
                  >
                    语言
                  </MDBDropdownToggle>
                  <MDBDropdownMenu>
                    <MDBDropdownItem>
                      <Link className="nav-link text-dark" to="/">
                        English &nbsp;
                        <img src={"/img/flag/uk.png"} height={25} alt="" />
                      </Link>
                    </MDBDropdownItem>
                    <MDBDropdownItem>
                      <Link className="nav-link text-dark" to="/gr">
                        German &nbsp;
                        <img src={"/img/flag/germany.png"} height={25} alt="" />
                      </Link>
                    </MDBDropdownItem>
                  </MDBDropdownMenu>
                </MDBDropdown>
              </MDBNavbarItem>
            </MDBNavbarNav>

            <div className="d-flex input-group w-auto">
              <a href="https://dapp.0xpad.app" className="btn-1">
                <span>启动应用程序</span>
              </a>
            </div>
          </MDBCollapse>
        </MDBContainer>
      </MDBNavbar>

      <MDBNavbar
        light
        bgColor="light"
        fixed="bottom"
        className="d-block d-md-none fixed-bottom bg-dark text-center p-2 text-nowrap"
      >
        <MDBRow>
          <MDBCol size={2} className="mx-auto">
            <a
              href="https://dapp.0xpad.app/invest"
              className="text-decoration-none text-white btn"
            >
              <img src={"/img/menu/menu_invest.png"} height={25} alt="" />{" "}
              <br />
              <small className="pt-2">投资</small>
            </a>
          </MDBCol>
          <MDBCol size={2} className="mx-auto">
            <a
              href="https://dapp.0xpad.app/trade"
              className="text-decoration-none text-white btn"
            >
              <img src={"/img/menu/menu_swap.png"} height={25} alt="" /> <br />
              <small className="pt-2">交换</small>
            </a>
          </MDBCol>
          <MDBCol size={2} className="mx-auto">
            <a
              href="https://medium.com/@zrxpad/cbc-comprehensive-background-check-c4fd3a6d6518"
              className="text-decoration-none text-white btn"
            >
              <img src={"/img/menu/menu_cbc.png"} height={25} alt="" /> <br />
              <small className="pt-2">加拿大广播公司</small>
            </a>
          </MDBCol>
          <MDBCol size={2} className="mx-auto">
            <a
              href="https://dapp.0xpad.app/trade"
              className="text-decoration-none text-white btn"
            >
              <img src={"/img/menu/menu_liquidity.png"} height={25} alt="" />{" "}
              <br />
              <small className="pt-2">流动性</small>
            </a>
          </MDBCol>
          <MDBCol size={2} className="mx-auto">
            <a
              onClick={toggleShow}
              className="text-decoration-none text-white btn"
            >
              <img src={"/img/menu/mobile_menu_more.svg"} alt="" /> <br />
              <small className="pt-2">更多的</small>
            </a>
          </MDBCol>
        </MDBRow>
      </MDBNavbar>

      <MDBModal show={basicModal} setShow={setBasicModal} tabIndex="-1">
        <MDBModalDialog>
          <MDBModalContent className="bg-black">
            <MDBModalHeader>
              <MDBModalTitle>更多的</MDBModalTitle>
              <MDBBtn
                className="btn-close bg-white"
                color="none"
                onClick={toggleShow}
              ></MDBBtn>
            </MDBModalHeader>
            <MDBModalBody>
              <MDBContainer className=" py-5">
                <MDBRow>
                  <MDBCol size={6} md="2" className="py-4">
                    <p className="text-decoration-underline text-capitalize lead">
                      投资
                    </p>
                    <p>
                      <a
                        href="https://dapp.0xpad.app/invest"
                        className="text-white"
                      >
                        发射台
                      </a>
                    </p>
                    <p className="text-decoration-underline text-capitalize lead">
                      贸易
                    </p>
                    <p>
                      <a
                        href="https://dapp.0xpad.app/trade"
                        className="text-white"
                      >
                        交换
                      </a>
                    </p>
                    <p>
                      <a
                        href="https://dapp.0xpad.app/trade"
                        className="text-white"
                      >
                        流动性
                      </a>
                    </p>
                  </MDBCol>
                  <MDBCol size={6} md="2" className="py-4">
                    <p className="text-decoration-underline text-capitalize lead">
                      买 ZXP
                    </p>
                    <p>
                      <a
                        href="https://dapp.0xpad.app/trade"
                        className="text-white"
                      >
                        0x 交换
                      </a>
                    </p>
                    <p>煎饼交换 </p>
                  </MDBCol>
                  <MDBCol size={6} md="2" className="py-4">
                    <p className="text-decoration-underline text-capitalize lead">
                      公司
                    </p>
                    <p>
                      <a
                        href="https://medium.com/@zrxpad"
                        className="text-white"
                      >
                        中等的
                      </a>
                    </p>
                    <p>
                      <a
                        href="https://0xpads-organization.gitbook.io/company-and-jobs-1/"
                        className="text-white"
                      >
                        职位公告板
                      </a>
                    </p>
                    <p>
                      <a
                        href="https://0xpads-organization.gitbook.io/company-and-jobs-1/"
                        className="text-white"
                      >
                        分析
                      </a>{" "}
                    </p>
                    <p className="text-decoration-underline text-capitalize lead">
                      支持
                    </p>
                    <p>
                      <a
                        href="https://0xpads-organization.gitbook.io/support/"
                        className="text-white"
                      >
                        常问问题
                      </a>
                    </p>
                  </MDBCol>
                  <MDBCol size={6} md="2" className="py-4">
                    <p className="text-decoration-underline text-capitalize lead">
                      开发商
                    </p>
                    <p>
                      <a
                        href="https://github.com/zrxpad"
                        className="text-white"
                      >
                        Github
                      </a>
                    </p>
                    <p>
                      <a
                        href="https://0xpads-organization.gitbook.io/untitled-1/"
                        className="text-white"
                      >
                        GitBook
                      </a>
                    </p>
                    <MDBDropdown>
                      <MDBDropdownToggle
                        tag="a"
                        className="btn btn-light btn-sm"
                      >
                        Language
                      </MDBDropdownToggle>
                      <MDBDropdownMenu>
                        <MDBDropdownItem className="px-3 py-1">
                          <Link className="nav-link text-dark" to="/gr">
                            German &nbsp;
                            <img
                              src={"/img/flag/germany.png"}
                              height={25}
                              alt=""
                            />
                          </Link>
                        </MDBDropdownItem>
                        <MDBDropdownItem className="px-3 py-1">
                          <Link className="nav-link text-dark" to="/">
                            English &nbsp;
                            <img src={"/img/flag/uk.png"} height={25} alt="" />
                          </Link>
                        </MDBDropdownItem>
                      </MDBDropdownMenu>
                    </MDBDropdown>
                  </MDBCol>
                </MDBRow>
              </MDBContainer>
            </MDBModalBody>
          </MDBModalContent>
        </MDBModalDialog>
      </MDBModal>
    </>
  );
}

import React, { Component } from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
  MDBCardImage,
  MDBBtn,
} from "mdb-react-ui-kit";
import Slider from "react-slick";

var settings = {
  className: "center",
  centerMode: false,
  centerPadding: "60px",
  dots: false,
  infinite: true,
  speed: 500,
  slidesToShow: 4,
  slidesToScroll: 1,
  initialSlide: 0,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true,
      },
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        initialSlide: 2,
      },
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
      },
    },
  ],
};

export default function FeaturedProjects() {
  return (
    <div className="text-white pb-5 my-md-5 py-md-5">
      <MDBContainer className="text-light my-5">
        <MDBRow>
          <MDBCol>
            <h2 className="fw-bold text-white">Featured
              <span className="text-gradient-3"> Projects</span>
            </h2>
            <p>
              Please note this section is for sponsored projects and does not
              guarantee our involvement or input. It is purely a rating and
              evaluation and should not be considered financial advice. For Tier
              1 projects please use our Launchpad.
            </p>
          </MDBCol>
        </MDBRow>
        <MDBRow className="overflow-md-hidden">
          <MDBCol className="mx-auto" size={10} md="12">
          <Slider {...settings} className="text-center">
            <div>
              <MDBCard className="featured-project-card m-3 rounded-xl position-relative border-0">
                <MDBCardImage
                  src="https://config-cms.impossible.finance/images/app-banner_pine_lp-ido_574x396px.png"
                  className="rounded-t-xl"
                  position="top"
                  style={{ height: "200px" }}
                  alt="..."
                />
                <div className="position-absolute top-0 start-0 p-2">
                  <span className="badge rounded-pill text-bg-pink">
                    #NFT
                  </span>
                </div>
                
                <MDBCardBody className="rounded-xl">
                  <MDBCardTitle>
                    <h4 className="fw-bold text-white">Aurigami BUSD</h4>
                  </MDBCardTitle>
                  <MDBCardText>
                    Some quick example text to build on the card.
                  </MDBCardText>
                  <button class="btn-custom">CBC Record</button>
                </MDBCardBody>
              </MDBCard>
            </div>
            <div>
              <MDBCard className="featured-project-card m-3 rounded-xl position-relative border-0">
                <MDBCardImage
                  src="https://config-cms.impossible.finance/images/app-banner_pine_lp-ido_574x396px.png"
                  className="rounded-t-xl"
                  position="top"
                  style={{ height: "200px" }}
                  alt="..."
                />
                <div className="position-absolute top-0 start-0 p-2">
                  <span className="badge rounded-pill text-bg-pink">
                    #NFT
                  </span>
                </div>
                
                <MDBCardBody className="rounded-xl">
                  <MDBCardTitle>
                    <h4 className="fw-bold text-white">Quoll Finance</h4>
                  </MDBCardTitle>
                  <MDBCardText>
                    Some quick example text to build on the card.
                  </MDBCardText>
                  <button class="btn-custom">CBC Record</button>
                </MDBCardBody>
              </MDBCard>
            </div>
            <div>
              <MDBCard className="featured-project-card m-3 rounded-xl position-relative border-0">
                <MDBCardImage
                  src="https://config-cms.impossible.finance/images/app-banner_pine_lp-ido_574x396px.png"
                  className="rounded-t-xl"
                  position="top"
                  style={{ height: "200px" }}
                  alt="..."
                />
                <div className="position-absolute top-0 start-0 p-2">
                  <span className="badge rounded-pill text-bg-pink">
                    #NFT
                  </span>
                </div>
                
                <MDBCardBody className="rounded-xl">
                  <MDBCardTitle>
                    <h4 className="fw-bold text-white">Pine Protocol</h4>
                  </MDBCardTitle>
                  <MDBCardText>
                    Some quick example text to build on the card.
                  </MDBCardText>
                  <button class="btn-custom">CBC Record</button>
                </MDBCardBody>
              </MDBCard>
            </div>
            <div>
              <MDBCard className="featured-project-card m-3 rounded-xl position-relative border-0">
                <MDBCardImage
                  src="https://config-cms.impossible.finance/images/app-banner_pine_lp-ido_574x396px.png"
                  className="rounded-t-xl"
                  position="top"
                  style={{ height: "200px" }}
                  alt="..."
                />
                <div className="position-absolute top-0 start-0 p-2">
                  <span className="badge rounded-pill text-bg-pink">
                    #NFT
                  </span>
                </div>
                
                <MDBCardBody className="rounded-xl">
                  <MDBCardTitle>
                    <h4 className="fw-bold text-white">Ruby</h4>
                  </MDBCardTitle>
                  <MDBCardText>
                    Some quick example text to build on the card.
                  </MDBCardText>
                  <button class="btn-custom">CBC Record</button>
                </MDBCardBody>
              </MDBCard>
            </div>
            <div>
              <MDBCard className="featured-project-card m-3 rounded-xl position-relative border-0">
                <MDBCardImage
                  src="https://config-cms.impossible.finance/images/app-banner_pine_lp-ido_574x396px.png"
                  className="rounded-t-xl"
                  position="top"
                  style={{ height: "200px" }}
                  alt="..."
                />
                <div className="position-absolute top-0 start-0 p-2">
                  <span className="badge rounded-pill text-bg-pink">
                    #NFT
                  </span>
                </div>
                
                <MDBCardBody className="rounded-xl">
                  <MDBCardTitle>
                    <h4 className="fw-bold text-white">Wirtual</h4>
                  </MDBCardTitle>
                  <MDBCardText>
                    Some quick example text to build on the card.
                  </MDBCardText>
                  <button class="btn-custom">CBC Record</button>
                </MDBCardBody>
              </MDBCard>
            </div>
          </Slider>
          </MDBCol>
        </MDBRow>
        <MDBRow className="text-center mt-5">
          <a href="https://github.com/zrxpad/CBC-records" className="btn-link">view more</a>
        </MDBRow>
      </MDBContainer>
    </div>
  );
}

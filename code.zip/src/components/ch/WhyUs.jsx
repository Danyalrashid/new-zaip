import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
} from "mdb-react-ui-kit";

export default function WhyUs() {
  return (
    <div style={{ backgroundColor: "#000000" }}>
    <MDBContainer className="text-light pb-5 my-md-5 py-md-5 why-us-bg-img">
        <MDBRow>
          <MDBCol>
            <h2 className="fw-bold text-white mb-5">
              我们如何
              <span className="text-gradient-3">是不同的</span>
            </h2>
          </MDBCol>
        </MDBRow>
        <MDBRow className="position-relative">
          <MDBCol size={6} md="4" className="position-absolute mt-5 bottom-0 start-0 z-n1">
            <img
              src={"img/quality/leftEarth.png"}
              alt="left"
              className="w-100"
            />
          </MDBCol>
          <MDBCol size={6} md="4" className="position-absolute mt-5 bottom-0 end-0 z-n1">
            <img
              src={"img/quality/rightEarth.png"}
              alt="right"
              className="w-100"
            />
          </MDBCol>
          <MDBCol md="6" className="py-4">
            <MDBCard className="why-us-card-bg  rounded-xxl h-100">
              <MDBCardBody className=" p-3 rounded-xxl">
                <div className="top-icon">
                  <img src={"img/different/high-quality.png"} alt="" />
                </div>
                <MDBRow>
                  <MDBCol md="3"></MDBCol>
                  <MDBCol md="9" className="py-4">
                    <MDBCardTitle>
                      <h3 className="fw-bold text-white mt-5 mt-md-0">
                        顶级项目
                      </h3>
                    </MDBCardTitle>
                    <MDBCardText>
                      随着 加拿大广播公司 标准的推出，我们尽到了应有的责任
                      勤奋，所以你不必。现在你可以轻松 参与顶级项目，无需思考
                      在进行投资之前。
                    </MDBCardText>
                  </MDBCol>
                </MDBRow>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="6" className="py-4">
            <MDBCard className="why-us-card-bg  rounded-xxl h-100">
              <MDBCardBody className=" p-3 rounded-xxl">
                <div className="top-icon">
                  <img src={"img/different/fair.png"} alt="" />
                </div>
                <MDBRow>
                  <MDBCol md="3"></MDBCol>
                  <MDBCol md="9" className="py-4">
                    <MDBCardTitle>
                      <h3 className="fw-bold text-white mt-5 mt-md-0">
                        公平和无障碍
                      </h3>
                    </MDBCardTitle>
                    <MDBCardText>
                      没有最低投资和基于订阅的 系统，我们的 launchpad
                      让所有人都能公平地带给你 你通常不会听说的新项目
                      直到他们已经成为主流！现在你不必
                      风险投资或私人销售以获得最优惠的价格
                    </MDBCardText>
                  </MDBCol>
                </MDBRow>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="6" className="py-4 mx-auto">
            <MDBCard className="why-us-card-bg  rounded-xxl h-100">
              <MDBCardBody className=" p-3 rounded-xxl">
                <div className="top-icon">
                  <img src={"img/different/hybrid.png"} alt="" />
                </div>
                <MDBRow>
                  <MDBCol md="3"></MDBCol>
                  <MDBCol md="9" className="py-4">
                    <MDBCardTitle>
                      <h3 className="fw-bold text-white mt-5 mt-md-0">
                        混合筹款活动
                      </h3>
                    </MDBCardTitle>
                    <MDBCardText>
                      许多项目由于营销和预算不佳而失败
                      拨款。通过我们的混合筹款活动，我们利用我们的
                      连接以获得溢价并提供一系列
                      以荒谬的折扣开展活动，以确保每个项目
                      与我们一起推出的是通过正确的营销来做到这一点 促进
                    </MDBCardText>
                  </MDBCol>
                </MDBRow>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </div>
  );
}

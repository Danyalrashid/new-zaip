import MainNavbar from '../components/en/MainNavbar';
import Banner from '../components/en/Banner';
import SocialIcons from '../components/en/SocialIcons';
import LatestUpdates from '../components/en/LatestUpdates';
import FeaturedProjects from '../components/en/FeaturedProjects';
import OurValues from '../components/en/OurValues';
import GetStarted from '../components/en/GetStarted';
import WhyUs from '../components/en/WhyUs';
import Roadmap from '../components/en/Roadmap';
import Tokenomics from '../components/en/Tokenomics';
import Footer from '../components/en/Footer';
import StayConnected from '../components/en/StayConnected';
import OurVision from '../components/en/OurVision';
import Investors from '../components/en/Investors';

function HomeEn() {
  return (
    <div>
      <div className='header-desktop-bg'>
        <MainNavbar />
        <Banner />
      </div>
      <SocialIcons />
      <LatestUpdates />
      <FeaturedProjects />
      <OurValues />
      <GetStarted />
      <WhyUs />
      <OurVision />
      <Roadmap />
      <Tokenomics />
      <Investors />
      <StayConnected />
      <Footer />
    </div>
  );
}

export default HomeEn;

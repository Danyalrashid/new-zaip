import React, { useState } from "react";
import {
  MDBContainer,
  MDBNavbar,
  MDBNavbarBrand,
  MDBNavbarNav,
  MDBNavbarItem,
  MDBNavbarLink,
  MDBDropdown,
  MDBDropdownToggle,
  MDBDropdownMenu,
  MDBDropdownItem,
  MDBCollapse,
  MDBRow,
  MDBCol,
  MDBBtn,
  MDBModal,
  MDBModalDialog,
  MDBModalContent,
  MDBModalHeader,
  MDBModalTitle,
  MDBModalBody,
} from "mdb-react-ui-kit";
import { Link } from "react-router-dom";

export default function MainNavbar() {
  const [basicModal, setBasicModal] = useState(false);
  const toggleShow = () => setBasicModal(!basicModal);

  return (
    <>
      <div className="container d-block d-md-none">
        <div className="row">
          <div className="col">
            <img src={"img/logo.png"} height={40} alt="" />
          </div>
        </div>
      </div>

      <MDBNavbar expand="md" dark className="py-4 d-none d-md-block">
        <MDBContainer>
          <MDBNavbarBrand>
            <img src={"img/logo.png"} height={40} alt="" />
          </MDBNavbarBrand>

          <MDBCollapse navbar>
            <MDBNavbarNav className="mr-auto mb-2 mb-lg-0 fw-bold">
              <MDBNavbarItem className="mx-4">
                <MDBNavbarLink
                  href="https://dapp.0xpad.app/invest"
                  className="text-white"
                >
                  Invest
                </MDBNavbarLink>
              </MDBNavbarItem>

              <MDBNavbarItem className="mx-4">
                <MDBNavbarLink
                  href="https://dapp.0xpad.app/trade"
                  className="text-white"
                >
                  Swap
                </MDBNavbarLink>
              </MDBNavbarItem>

              <MDBNavbarItem className="mx-4">
                <MDBNavbarLink
                  href="https://medium.com/@zrxpad/cbc-comprehensive-background-check-c4fd3a6d6518"
                  className="text-white"
                >
                  CBC
                </MDBNavbarLink>
              </MDBNavbarItem>

              <MDBNavbarItem className="mx-4">
                <MDBNavbarLink
                  href="https://dapp.0xpad.app/trade"
                  className="text-white"
                >
                  Liquidity
                </MDBNavbarLink>
              </MDBNavbarItem>

              <MDBNavbarItem className="mx-4">
                <MDBNavbarLink
                  href="https://0xpads-organization.gitbook.io/support/"
                  className="text-white"
                >
                  FAQ
                </MDBNavbarLink>
              </MDBNavbarItem>

              <MDBNavbarItem className="mx-4">
                <MDBNavbarLink href={"whitepaper.pdf"} className="text-white">
                  Whitepaper
                </MDBNavbarLink>
              </MDBNavbarItem>

              <MDBNavbarItem>
                <MDBDropdown>
                  <MDBDropdownToggle
                    tag="a"
                    className="nav-link text-white"
                    role="button"
                  >
                    Language
                  </MDBDropdownToggle>
                  <MDBDropdownMenu>
                    <MDBDropdownItem>
                      <Link className="nav-link text-dark" to="/gr">
                        German &nbsp;
                        <img src={"/img/flag/germany.png"} height={25} alt="" />
                      </Link>
                    </MDBDropdownItem>
                    <MDBDropdownItem>
                      <Link className="nav-link text-dark" to="/ch">
                        Chinese &nbsp;
                        <img src={"/img/flag/china.png"} height={25} alt="" />
                      </Link>
                    </MDBDropdownItem>
                  </MDBDropdownMenu>
                </MDBDropdown>
              </MDBNavbarItem>
            </MDBNavbarNav>

            <div className="d-flex input-group w-auto">
              <a href="https://dapp.0xpad.app" className="btn-1">
                <span>Launch App</span>
              </a>
            </div>
          </MDBCollapse>
        </MDBContainer>
      </MDBNavbar>

      <MDBNavbar
        light
        bgColor="light"
        fixed="bottom"
        className="d-block d-md-none fixed-bottom bg-dark text-center p-2"
      >
        <MDBRow>
          <MDBCol size={2} className="mx-auto">
            <a
              href="https://dapp.0xpad.app/invest"
              className="text-decoration-none text-white btn"
            >
              <img src={"/img/menu/menu_invest.png"} height={25} alt="" />
              <small className="pt-2">Invest</small>
            </a>
          </MDBCol>
          <MDBCol size={2} className="mx-auto">
            <a
              href="https://dapp.0xpad.app/trade"
              className="text-decoration-none text-white btn"
            >
              <img src={"/img/menu/menu_swap.png"} height={25} alt="" />
              <small className="pt-2">Swap</small>
            </a>
          </MDBCol>
          <MDBCol size={2} className="mx-auto">
            <a
              href="https://medium.com/@zrxpad/cbc-comprehensive-background-check-c4fd3a6d6518"
              className="text-decoration-none text-white btn"
            >
              <img src={"/img/menu/menu_cbc.png"} height={25} alt="" />
              <small className="pt-2">CBC</small>
            </a>
          </MDBCol>
          <MDBCol size={2} className="mx-auto">
            <a
              href="https://dapp.0xpad.app/trade"
              className="text-decoration-none text-white btn"
            >
              <img src={"/img/menu/menu_liquidity.png"} height={25} alt="" />
              <small className="pt-2">Liquidity</small>
            </a>
          </MDBCol>
          <MDBCol size={2} className="mx-auto">
            <a
              onClick={toggleShow}
              className="text-decoration-none text-white btn"
            >
              <img src={"/img/menu/mobile_menu_more.svg"} alt="" />
              <small className="pt-2">More</small>
            </a>
          </MDBCol>
        </MDBRow>
      </MDBNavbar>

      <MDBModal show={basicModal} setShow={setBasicModal} tabIndex="-1">
        <MDBModalDialog>
          <MDBModalContent className="bg-black">
            <MDBModalHeader>
              <MDBModalTitle>More</MDBModalTitle>
              <MDBBtn
                className="btn-close bg-white"
                color="none"
                onClick={toggleShow}
              ></MDBBtn>
            </MDBModalHeader>
            <MDBModalBody>
              <MDBContainer className="py-5">
                <MDBRow>
                  <MDBCol size={6} md="2" className="py-4">
                    <p className="text-decoration-underline text-capitalize lead">
                      Invest
                    </p>
                    <p>
                      <a
                        href="https://dapp.0xpad.app/invest"
                        className="text-white"
                      >
                        Launchpad
                      </a>
                    </p>
                    <p className="text-decoration-underline text-capitalize lead">
                      Trade
                    </p>
                    <p>
                      <a
                        href="https://dapp.0xpad.app/trade"
                        className="text-white"
                      >
                        Swap
                      </a>
                    </p>
                    <p>
                      <a
                        href="https://dapp.0xpad.app/trade"
                        className="text-white"
                      >
                        Liquidity
                      </a>
                    </p>
                  </MDBCol>
                  <MDBCol size={6} md="2" className="py-4">
                    <p className="text-decoration-underline text-capitalize lead">
                      Buy ZXP
                    </p>
                    <p>
                      <a
                        href="https://dapp.0xpad.app/trade"
                        className="text-white"
                      >
                        0x Swap
                      </a>
                    </p>
                    <p>PancakeSwap </p>
                  </MDBCol>
                  <MDBCol size={6} md="2" className="py-4">
                    <p className="text-decoration-underline text-capitalize lead">
                      Company
                    </p>
                    <p>
                      <a
                        href="https://medium.com/@zrxpad"
                        className="text-white"
                      >
                        Medium
                      </a>
                    </p>
                    <p>
                      <a
                        href="https://0xpads-organization.gitbook.io/company-and-jobs-1/"
                        className="text-white"
                      >
                        Job Board
                      </a>
                    </p>
                    <p>
                      <a
                        href="https://0xpads-organization.gitbook.io/company-and-jobs-1/"
                        className="text-white"
                      >
                        Analytics
                      </a>{" "}
                    </p>
                    <p className="text-decoration-underline text-capitalize lead">
                      Support
                    </p>
                    <p>
                      <a
                        href="https://0xpads-organization.gitbook.io/support/"
                        className="text-white"
                      >
                        FAQ
                      </a>
                    </p>
                  </MDBCol>
                  <MDBCol size={6} md="2" className="py-4">
                    <p className="text-decoration-underline text-capitalize lead">
                      Developers
                    </p>
                    <p>
                      <a
                        href="https://github.com/zrxpad"
                        className="text-white"
                      >
                        Github
                      </a>
                    </p>
                    <p>
                      <a
                        href="https://0xpads-organization.gitbook.io/untitled-1/"
                        className="text-white"
                      >
                        GitBook
                      </a>
                    </p>
                    <MDBDropdown>
                      <MDBDropdownToggle
                        tag="a"
                        className="btn btn-light btn-sm"
                      >
                        Language
                      </MDBDropdownToggle>
                      <MDBDropdownMenu>
                        <MDBDropdownItem className="px-3 py-1">
                          <Link className="nav-link text-dark" to="/gr">
                            German &nbsp;
                            <img
                              src={"/img/flag/germany.png"}
                              height={25}
                              alt=""
                            />
                          </Link>
                        </MDBDropdownItem>
                        <MDBDropdownItem className="px-3 py-1">
                          <Link className="nav-link text-dark" to="/ch">
                            Chinese &nbsp;
                            <img
                              src={"/img/flag/china.png"}
                              height={25}
                              alt=""
                            />
                          </Link>
                        </MDBDropdownItem>
                      </MDBDropdownMenu>
                    </MDBDropdown>
                  </MDBCol>
                </MDBRow>
              </MDBContainer>
            </MDBModalBody>
          </MDBModalContent>
        </MDBModalDialog>
      </MDBModal>
    </>
  );
}

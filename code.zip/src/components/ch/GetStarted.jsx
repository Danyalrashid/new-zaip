import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
} from "mdb-react-ui-kit";

export default function GetStarted() {
  return (
    <>
    <MDBContainer className="text-light pb-5 my-md-5 py-md-5">
        <MDBRow>
          <MDBCol>
            <h2 className="fw-bold text-white text-center">
              <span className="text-gradient-4">3 步开始</span>
            </h2>
          </MDBCol>
        </MDBRow>
        <MDBRow>
          <MDBCol md="4" className="py-4">
            <MDBCard className="steps-card-bg  rounded-xxl h-100">
              <MDBCardBody className=" p-5 rounded-xxl">
                <MDBCardTitle>
                  <p>步1</p>
                  <h3 className="fw-bold text-white">连接
</h3>
                </MDBCardTitle>
                <img src={"img/get-started/coin.png"} alt="" />
                <MDBCardText>
                在您的钱包中连接至少 100 个 ZXP 代币以访问
                  垫。

                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="4" className="py-4">
            <MDBCard className="steps-card-bg  rounded-xxl h-100">
              <MDBCardBody className=" p-5 rounded-xxl">
                <MDBCardTitle>
                  <p>步2</p>
                  <h3 className="fw-bold text-white">购买</h3>
                </MDBCardTitle>
                <img src={"img/get-started/dollar.png"} alt="" />
                <MDBCardText>
购买 ZXP 代币开始.</MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="4" className="py-4">
            <MDBCard className="steps-card-bg rounded-xxl h-100">
              <MDBCardBody className=" p-5 rounded-xxl">
                <MDBCardTitle>
                  <p>步3</p>
                  <h3 className="fw-bold text-white">赌注</h3>
                </MDBCardTitle>
                <img src={"img/get-started/wallet.png"} alt="" />
                <MDBCardText>
                将您的 ZXP 代币投入到一个项目中，以便能够购买
                  它的预售。您投入的资金越多，您可以投资的资金就越多。
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </>
  );
}

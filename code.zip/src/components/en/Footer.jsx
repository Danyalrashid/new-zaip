import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBDropdown,
  MDBDropdownItem,
  MDBDropdownMenu,
  MDBDropdownToggle,
} from "mdb-react-ui-kit";
import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <>
      <div className="container-fluid gradient-line"></div>
      <div className="bg-dark-blue text-light">
        <MDBContainer className="py-5">
          <MDBRow>
            <MDBCol md="4" className="py-4">
              <div>
                <img src={"img/logo.png"} height={50} alt="" />
              </div>
              <div className="mt-3 d-none d-md-block">
                <a href="https://t.me/zrxpad">
                  <img
                    height={30}
                    src={"img/social/telegram icon.png"}
                    alt=""
                  />{" "}
                  &nbsp;
                </a>
                <a href="https://twitter.com/zrxpad">
                  <img height={30} src={"img/social/twitter.png"} alt="" />{" "}
                  &nbsp;
                </a>
                <a href="https://github.com/zrxpad">
                  <img height={30} src={"img/social/github.png"} alt="" />{" "}
                  &nbsp;
                </a>
                <a href="https://medium.com/@zrxpad">
                  <img height={30} src={"img/social/medium.png"} alt="" />
                </a>
              </div>
            </MDBCol>
              <MDBCol size={6} md="2" className="py-4">
                <p className="text-decoration-underline text-capitalize lead">
                  Invest
                </p>
                <p>
                  <a href="https://dapp.0xpad.app/invest" className="text-white">
                    Launchpad
                  </a>
                </p>
                <p className="text-decoration-underline text-capitalize lead">
                  Trade
                </p>
                <p>
                  <a href="https://dapp.0xpad.app/trade" className="text-white">
                    Swap
                  </a>
                </p>
                <p>
                  <a href="https://dapp.0xpad.app/trade" className="text-white">
                    Liquidity
                  </a>
                </p>
            </MDBCol>
            <MDBCol size={6} md="2" className="py-4">
              <p className="text-decoration-underline text-capitalize lead">
                Buy ZXP
              </p>
              <p>
                <a href="https://dapp.0xpad.app/trade" className="text-white">
                  0x Swap
                </a>
              </p>
              <p>PancakeSwap </p>
            </MDBCol>
            <MDBCol size={6} md="2" className="py-4">
              <p className="text-decoration-underline text-capitalize lead">
                Company
              </p>
              <p>
                <a href="https://medium.com/@zrxpad" className="text-white">
                  Medium
                </a>
              </p>
              <p><a href="https://0xpads-organization.gitbook.io/company-and-jobs-1/" className="text-white">Job Board</a></p>
              <p><a href="https://0xpads-organization.gitbook.io/company-and-jobs-1/" className="text-white">Analytics</a> </p>
              <p className="text-decoration-underline text-capitalize lead">
                Support
              </p>
              <p><a href="https://0xpads-organization.gitbook.io/support/" className="text-white">FAQ</a></p>
            </MDBCol>
            <MDBCol size={6} md="2" className="py-4">
              <p className="text-decoration-underline text-capitalize lead">
                Developers
              </p>
              <p>
                <a href="https://github.com/zrxpad" className="text-white">
                  Github
                </a>
              </p>
              <p>
                <a href="https://0xpads-organization.gitbook.io/untitled-1/" className="text-white">
                  GitBook
                </a>
              </p>
              <MDBDropdown>
                <MDBDropdownToggle tag="a" className="btn btn-light btn-sm">
                  Language
                </MDBDropdownToggle>
                <MDBDropdownMenu>
                  <MDBDropdownItem className="px-3 py-1">
                    <Link className="nav-link text-dark" to="/gr">
                      German &nbsp;
                      <img src={"/img/flag/germany.png"} height={25} alt="" />
                    </Link>
                  </MDBDropdownItem>
                  <MDBDropdownItem className="px-3 py-1">
                    <Link className="nav-link text-dark" to="/ch">
                      Chinese &nbsp;
                      <img src={"/img/flag/china.png"} height={25} alt="" />
                    </Link>
                  </MDBDropdownItem>
                </MDBDropdownMenu>
              </MDBDropdown>
            </MDBCol>
          </MDBRow>
        </MDBContainer>
        <MDBContainer className="small pb-5 mb-5 py-md-3 text-center">
          0xpad &copy; 2023
        </MDBContainer>
      </div>
    </>
  );
}

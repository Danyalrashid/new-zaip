import React from "react";
import { MDBContainer, MDBRow, MDBCol } from "mdb-react-ui-kit";

export default function OurVision() {
  return (
    <>
      <MDBContainer className="text-light pb-5 my-md-5 py-md-5">
        <MDBRow className="d-flex">
          <MDBCol md="6" className="py-4 align-self-center">
            <h2 className="fw-bold text-white">
              <span className="text-gradient-3">Was ist</span>
              unsere Vision
            </h2>
            <p className="lead">
              Um unseren Investoren die besten der besten Top-Tier-Projekte zu
              bringen und bestrebt, die Nummer 1 der Launchpads in Sachen
              Qualität zu sein Raum und nutzen gleichzeitig unser Netzwerk, um
              das beste Marketing zu bieten Unterstützung für Startups.
            </p>
          </MDBCol>
          <MDBCol md="6" className="py-4 text-end">
            <img src={"img/our-vision.gif"} className="w-100" alt="" />
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </>
  );
}

import "./App.css";
import HomeEn from "./page/HomeEn";
import HomeGr from "./page/HomeGr";
import HomeCh from "./page/HomeCh";

import { Routes, Route } from "react-router-dom";

function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<HomeEn />}></Route>
        <Route path="/gr" element={<HomeGr />}></Route>
        <Route path="/ch" element={<HomeCh />}></Route>
      </Routes>
    </>
  );
}

export default App;

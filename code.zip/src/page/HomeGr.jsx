import MainNavbar from '../components/gr/MainNavbar';
import Banner from '../components/gr/Banner';
import SocialIcons from '../components/gr/SocialIcons';
import LatestUpdates from '../components/gr/LatestUpdates';
import FeaturedProjects from '../components/gr/FeaturedProjects';
import OurValues from '../components/gr/OurValues';
import GetStarted from '../components/gr/GetStarted';
import WhyUs from '../components/gr/WhyUs';
import Roadmap from '../components/gr/Roadmap';
import Tokenomics from '../components/gr/Tokenomics';
import Footer from '../components/gr/Footer';
import StayConnected from '../components/gr/StayConnected';
import OurVision from '../components/gr/OurVision';
import Investors from '../components/gr/Investors';

function HomeGr() {
  return (
    <div>
      <div className='header-desktop-bg'>
        <MainNavbar />
        <Banner />
      </div>
      <SocialIcons />
      <LatestUpdates />
      <FeaturedProjects />
      <OurValues />
      <GetStarted />
      <WhyUs />
      <OurVision />
      <Roadmap />
      <Tokenomics />
      <Investors />
      <StayConnected />
      <Footer />
    </div>
  );
}

export default HomeGr;

import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
} from "mdb-react-ui-kit";

export default function WhyUs() {
  return (
    <div style={{ backgroundColor: "#000000" }}>
      <MDBContainer className="text-light pb-5 my-md-5 py-md-5 why-us-bg-img">
        <MDBRow>
          <MDBCol>
            <h2 className="fw-bold text-white mb-5">
              Wie wir
              <span className="text-gradient-3">sind anders</span>
            </h2>
          </MDBCol>
        </MDBRow>
        <MDBRow className="position-relative">
          <MDBCol size={6} md="4" className="position-absolute mt-5 bottom-0 start-0 z-n1">
            <img
              src={"img/quality/leftEarth.png"}
              alt="left"
              className="w-100"
            />
          </MDBCol>
          <MDBCol size={6} md="4" className="position-absolute mt-5 bottom-0 end-0 z-n1">
            <img
              src={"img/quality/rightEarth.png"}
              alt="right"
              className="w-100"
            />
          </MDBCol>
          <MDBCol md="6" className="py-4">
            <MDBCard className="why-us-card-bg  rounded-xxl h-100">
              <MDBCardBody className=" p-3 rounded-xxl">
                <div className="top-icon">
                  <img src={"img/different/high-quality.png"} alt="" />
                </div>
                <MDBRow>
                  <MDBCol md="3"></MDBCol>
                  <MDBCol md="9" className="py-4">
                    <MDBCardTitle>
                      <h3 className="fw-bold text-white mt-5 mt-md-0">
                        Top-Tier-Projekt
                      </h3>
                    </MDBCardTitle>
                    <MDBCardText>
                      Mit der Einführung des CBC-Standards tun wir das, was
                      fällig ist Fleiß, damit Sie es nicht müssen. Jetzt können
                      Sie ganz einfach an erstklassigen Projekten teilnehmen und
                      nicht nachdenken müssen bevor Sie eine Investition
                      nachäffen.
                    </MDBCardText>
                  </MDBCol>
                </MDBRow>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="6" className="py-4">
            <MDBCard className="why-us-card-bg  rounded-xxl h-100">
              <MDBCardBody className=" p-3 rounded-xxl">
                <div className="top-icon">
                  <img src={"img/different/fair.png"} alt="" />
                </div>
                <MDBRow>
                  <MDBCol md="3"></MDBCol>
                  <MDBCol md="9" className="py-4">
                    <MDBCardTitle>
                      <h3 className="fw-bold text-white mt-5 mt-md-0">
                        Fair und zugänglich
                      </h3>
                    </MDBCardTitle>
                    <MDBCardText>
                      Ohne Mindestinvestition und auf Abonnementbasis System,
                      unser Launchpad macht es fair für alle, die Sie bringen
                      neue Projekte, von denen Sie sonst nie gehört hätten bis
                      sie bereits Mainstream sind! Jetzt müssen Sie nicht sein
                      einem VC oder in einem Privatverkauf, um die besten
                      Angebote zu erhalten.
                    </MDBCardText>
                  </MDBCol>
                </MDBRow>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="6" className="py-4 mx-auto">
            <MDBCard className="why-us-card-bg  rounded-xxl h-100">
              <MDBCardBody className=" p-3 rounded-xxl">
                <div className="top-icon">
                  <img src={"img/different/hybrid.png"} alt="" />
                </div>
                <MDBRow>
                  <MDBCol md="3"></MDBCol>
                  <MDBCol md="9" className="py-4">
                    <MDBCardTitle>
                      <h3 className="fw-bold text-white mt-5 mt-md-0">
                        Hybride Spendenaktion
                      </h3>
                    </MDBCardTitle>
                    <MDBCardText>
                      Viele Projekte scheitern an schlechtem Marketing und
                      Budget Zuweisungen. Mit unserer hybriden Spendenaktion
                      nutzen wir unsere Verbindungen, um Premium-Preise zu
                      erhalten und eine Reihe von anzubieten Kampagnen mit
                      absurden Rabatten, um jedes Projekt sicherzustellen was
                      bei uns durchstartet, tut dies mit dem richtigen Marketing
                      Schub.
                    </MDBCardText>
                  </MDBCol>
                </MDBRow>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </div>
  );
}

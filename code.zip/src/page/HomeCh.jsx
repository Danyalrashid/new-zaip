import MainNavbar from '../components/ch/MainNavbar';
import Banner from '../components/ch/Banner';
import SocialIcons from '../components/ch/SocialIcons';
import LatestUpdates from '../components/ch/LatestUpdates';
import FeaturedProjects from '../components/ch/FeaturedProjects';
import OurValues from '../components/ch/OurValues';
import GetStarted from '../components/ch/GetStarted';
import WhyUs from '../components/ch/WhyUs';
import Roadmap from '../components/ch/Roadmap';
import Tokenomics from '../components/ch/Tokenomics';
import Footer from '../components/ch/Footer';
import StayConnected from '../components/ch/StayConnected';
import OurVision from '../components/ch/OurVision';
import Investors from '../components/ch/Investors';

function HomeCh() {
  return (
    <div>
      <div className='header-desktop-bg'>
        <MainNavbar />
        <Banner />
      </div>
      <SocialIcons />
      <LatestUpdates />
      <FeaturedProjects />
      <OurValues />
      <GetStarted />
      <WhyUs />
      <OurVision />
      <Roadmap />
      <Tokenomics />
      <Investors />
      <StayConnected />
      <Footer />
    </div>
  );
}

export default HomeCh;

import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
} from "mdb-react-ui-kit";

export default function GetStarted() {
  return (
    <>
      <MDBContainer className="text-light pb-5 my-md-5 py-md-5">
        <MDBRow>
          <MDBCol>
            <h2 className="fw-bold text-white text-center">
              <span className="text-gradient-4">Get started in 3 Steps</span>
            </h2>
          </MDBCol>
        </MDBRow>
        <MDBRow>
          <MDBCol md="4" className="py-4">
            <MDBCard className="steps-card-bg  rounded-xxl h-100">
              <MDBCardBody className=" p-5 rounded-xxl">
                <MDBCardTitle>
                  <p>Step 1</p>
                  <h3 className="fw-bold text-white">CONNECT</h3>
                </MDBCardTitle>
                <img src={"img/get-started/coin.png"} alt="" />
                <MDBCardText>
                  Connect with at least 100 ZXP tokens in your wallet to access
                  the pad.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="4" className="py-4">
            <MDBCard className="steps-card-bg  rounded-xxl h-100">
              <MDBCardBody className=" p-5 rounded-xxl">
                <MDBCardTitle>
                  <p>Step 2</p>
                  <h3 className="fw-bold text-white">PURCHASE</h3>
                </MDBCardTitle>
                <img src={"img/get-started/dollar.png"} alt="" />
                <MDBCardText>Purchase ZXP tokens to get started.</MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="4" className="py-4">
            <MDBCard className="steps-card-bg rounded-xxl h-100">
              <MDBCardBody className=" p-5 rounded-xxl">
                <MDBCardTitle>
                  <p>Step 3</p>
                  <h3 className="fw-bold text-white">STAKE</h3>
                </MDBCardTitle>
                <img src={"img/get-started/wallet.png"} alt="" />
                <MDBCardText>
                  Stake your ZXP tokens into a project to be able to buy into
                  its pre sale. The more you stake the more you can invest.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </>
  );
}

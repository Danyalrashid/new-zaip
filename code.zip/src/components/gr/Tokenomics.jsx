import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
} from "mdb-react-ui-kit";

export default function Tokenomics() {
  return (
    <>
    <MDBContainer className="text-light pb-5 my-md-5 py-md-5">
        <MDBRow>
          <MDBCol>
            <h2 className="fw-bold text-white text-white">
              <span className="text-gradient-3">Tokenomik</span>
            </h2>
          </MDBCol>
        </MDBRow>
        <MDBRow>
          <MDBCol md={6}>
            <img src={"img/tokenomics.jpg"} className="w-100" alt="" />
          </MDBCol>
          <MDBCol md={6} className="pt-0 mt-0 pt-md-5 mt-md-5">
            <ul className="tokenomics">
                <li className="presale">
                    <span className="dot bg"></span>
                    <span>Vorverkauf</span>
                    <span className="text">44%</span>
                </li>
                <li className="liquidity">
                    <span className="dot bg"></span>
                    <span>Liquidität</span>
                    <span className="text">22%</span>
                </li>
                <li className="shill2earn">
                    <span className="dot bg"></span>
                    <span>Shill2earn</span>
                    <span className="text">10%</span>
                </li>
                <li className="liquidity-swap">
                    <span className="dot bg"></span>
                    <span>Liquidität Pro 0x Tauschen</span>
                    <span className="text">9%</span>
                </li>
                <li className="cex-listing-1">
                    <span className="dot bg"></span>
                    <span>CEX Auflistung 1</span>
                    <span className="text">6%</span>
                </li>
                <li className="cex-listing-2">
                    <span className="dot bg"></span>
                    <span>CEX Auflistung 2</span>
                    <span className="text">6%</span>
                </li>
                <li className="team">
                    <span className="dot bg"></span>
                    <span>Mannschaft</span>
                    <span className="text">3%</span>
                </li>
            </ul>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </>
  );
}

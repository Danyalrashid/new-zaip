import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
} from "mdb-react-ui-kit";
import Slider from "react-slick";

var settings = {
  className: "center",
  centerMode: false,
  centerPadding: "60px",
  dots: false,
  infinite: true,
  speed: 500,
  slidesToShow: 1,
  slidesToScroll: 1,
  initialSlide: 1,
};

export default function Investors() {
  return (
    <div>
    <MDBContainer className="text-light pb-5 my-md-5 py-md-5">
        <MDBRow>
          <MDBCol>
            <h2 className="fw-bold text-white">
              <span className="text-gradient-3">Investoren</span>
            </h2>
            <p>
            Unsere strategischen Partner sind Teil des Impossible Ecosystems.

            </p>
          </MDBCol>
        </MDBRow>
        <MDBRow className="position-relative overflow-md-hidden">
          <MDBCol className="mx-auto" size={10} md="12">
            <Slider {...settings}>
              <div>
              <img src={"img/coming-soon.jpg"} className="w-100" alt="" />
              </div>
              <div>
              <img src={"img/coming-soon.jpg"} className="w-100" alt="" />
              </div>
            </Slider>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </div>
  );
}

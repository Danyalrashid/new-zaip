import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardImage,
} from "mdb-react-ui-kit";
import Slider from "react-slick";

var settings = {
  className: "center",
  centerMode: false,
  centerPadding: "60px",
  dots: false,
  infinite: true,
  speed: 500,
  slidesToShow: 4,
  slidesToScroll: 1,
  initialSlide: 0,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true,
      },
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        initialSlide: 2,
      },
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
      },
    },
  ],
};

export default function LatestUpdates() {
  return (
    <>
      <MDBContainer className="text-light py-5 my-md-5 pt-md-5">
        <MDBRow>
          <MDBCol>
            <h2 className="fw-bold text-white">
              <span className="text-gradient-3">Latest</span> Updates
            </h2>
            <p>
              Find information on our partnered projects using our launchpad,
              upcoming AMA sessions and upcoming opportunities.
            </p>
          </MDBCol>
        </MDBRow>
        <MDBRow className="overflow-md-hidden">
          <MDBCol className="mx-auto" size={10} md="12">
          <Slider {...settings} className="text-center">
            <div>
              <MDBCard className="shadow-blue">
                <MDBCardImage
                  src={"img/updates/1.png"}
                  className="rounded-xxl"
                  position="top"
                  alt="..."
                />
              </MDBCard>
            </div>
            <div>
              <MDBCard className="shadow-blue">
                <MDBCardImage
                  src={"img/updates/2.png"}
                  className="rounded-xxl"
                  position="top"
                  alt="..."
                />
              </MDBCard>
            </div>
            <div>
              <MDBCard className="shadow-blue">
                <MDBCardImage
                  src={"img/updates/3.png"}
                  className="rounded-xxl"
                  position="top"
                  alt="..."
                />
              </MDBCard>
            </div>
            <div>
              <MDBCard className="shadow-blue">
                <MDBCardImage
                  src={"img/updates/4.png"}
                  className="rounded-xxl"
                  position="top"
                  alt="..."
                />
              </MDBCard>
            </div>
          </Slider>
          </MDBCol>
        </MDBRow>
        <MDBRow className="text-center mt-5">
          <MDBCol>
          <a href="https://medium.com/@zrxpad" className="btn-link">
            more
          </a>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </>
  );
}

import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
} from "mdb-react-ui-kit";

export default function GetStarted() {
  return (
    <>
    <MDBContainer className="text-light pb-5 my-md-5 py-md-5">
        <MDBRow>
          <MDBCol>
            <h2 className="fw-bold text-white text-center">
              <span className="text-gradient-4">Starten Sie in 3 Schritten</span>
            </h2>
          </MDBCol>
        </MDBRow>
        <MDBRow>
          <MDBCol md="4" className="py-4">
            <MDBCard className="steps-card-bg  rounded-xxl h-100">
              <MDBCardBody className=" p-5 rounded-xxl">
                <MDBCardTitle>
                  <p>Schritt1</p>
                  <h3 className="fw-bold text-white">ANSCHLIESSEN</h3>
                </MDBCardTitle>
                <img src={"img/get-started/coin.png"} alt="" />
                <MDBCardText>
                Verbinden Sie sich mit mindestens 100 ZXP-Token in Ihrer Brieftasche, um darauf zuzugreifen
                  die Unterlage.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="4" className="py-4">
            <MDBCard className="steps-card-bg  rounded-xxl h-100">
              <MDBCardBody className=" p-5 rounded-xxl">
                <MDBCardTitle>
                  <p>Schritt2</p>
                  <h3 className="fw-bold text-white">KAUFEN</h3>
                </MDBCardTitle>
                <img src={"img/get-started/dollar.png"} alt="" />
                <MDBCardText>Kaufen Sie ZXP-Token, um loszulegen.</MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol md="4" className="py-4">
            <MDBCard className="steps-card-bg rounded-xxl h-100">
              <MDBCardBody className=" p-5 rounded-xxl">
                <MDBCardTitle>
                  <p>Schritt3</p>
                  <h3 className="fw-bold text-white">EINSATZ</h3>
                </MDBCardTitle>
                <img src={"img/get-started/wallet.png"} alt="" />
                <MDBCardText>
                Setzen Sie Ihre ZXP-Token in ein Projekt ein, um sich einkaufen zu können
                  sein Vorverkauf. Je mehr Sie einsetzen, desto mehr können Sie investieren.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </>
  );
}
